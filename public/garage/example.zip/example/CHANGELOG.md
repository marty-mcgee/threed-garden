# example

## 1.1.0

### Minor Changes

- 85c80e70: eventsource and eventprefix on the canvas component

## 1.0.0

### Major Changes

- 385ba9c: v8 major, react-18 compat
- 04c07b8: v8 major, react-18 compat

## 1.0.0-beta.0

### Major Changes

- 385ba9c: v8 major, react-18 compat
